package com.example.backendtestproject.controller;

import com.example.backendtestproject.model.ApplicationInfo;
import com.example.backendtestproject.model.User;
import com.example.backendtestproject.model.UserApps;
import com.example.backendtestproject.model.UserAppsDto;
import com.example.backendtestproject.repository.ApplicationInfoRepository;
import com.example.backendtestproject.repository.UserAppsRepository;
import com.example.backendtestproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.List;

@RestController
@CrossOrigin("http://localhost:5173")
public class ApplicationInfoController {

    @Autowired
    private ApplicationInfoRepository applicationInfoRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserAppsRepository userAppsRepository;


    @PostMapping("/appinfo")
    ApplicationInfo newApplicationInfo(@RequestBody ApplicationInfo newApplicationInfo) {
        return applicationInfoRepository.save(newApplicationInfo);
    }

    @GetMapping("/appinfos")
    List<ApplicationInfo> getAllApplicationInfo() {
        return applicationInfoRepository.findAll();
    }

    @PostMapping("/userapp")
    UserApps assignApptoUser(@RequestBody UserAppsDto userAppsDto) {

        Integer userId = userAppsDto.getUserId();
        Integer applicationId = userAppsDto.getApplicationInfoId();

        User user = userRepository.findById(userId).orElse(null);
        ApplicationInfo applicationInfo = applicationInfoRepository.findById(applicationId).orElse(null);

        if(user!= null && applicationInfo!=null){

            UserApps userApps = new UserApps();
            userApps.setApplicationInfo(applicationInfo);
            userApps.setUser(user);
            userApps.setCreated_at(new Timestamp(System.currentTimeMillis()));
            userApps.setModified_at(new Timestamp(System.currentTimeMillis()));

            return userAppsRepository.save(userApps);
        }else{

            return new UserApps();
        }

        //return userAppsRepository.save(userApps);


    }

    @DeleteMapping("/appinfo/{id}")
    void deleteApplicationInfo(@PathVariable Integer id) {
        applicationInfoRepository.deleteById(id);
    }


}