package com.example.backendtestproject.repository;

import com.example.backendtestproject.model.ServerInfo;
import com.example.backendtestproject.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServerInfoRepository extends JpaRepository<ServerInfo, Integer> {
}
