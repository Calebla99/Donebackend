package com.example.backendtestproject.model;

import com.example.backendtestproject.model.ApplicationInfo;
import com.example.backendtestproject.model.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;
import java.sql.Timestamp;

@Data
@Entity
public class UserApps {

    @Id
    @JsonIgnore
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer user_app_uid;

    @ManyToOne
    @JoinColumn(name = "appInfoUid")
    @JsonIgnore
    private ApplicationInfo applicationInfo;


    @ManyToOne
    @JoinColumn(name = "userUid")
    @JsonIgnore
    private User user;

    private Timestamp created_at;
    private String created_by;
    private Timestamp modified_at;
    private String modified_by;


    public Integer getUser_app_uid() {
        return user_app_uid;
    }

    public void setUser_app_uid(Integer user_app_uid) {
        this.user_app_uid = user_app_uid;
    }

    public ApplicationInfo getApplicationInfo() {
        return applicationInfo;
    }

    public void setApplicationInfo(ApplicationInfo applicationInfo) {
        this.applicationInfo = applicationInfo;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Timestamp getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Timestamp created_at) {
        this.created_at = created_at;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Timestamp getModified_at() {
        return modified_at;
    }

    public void setModified_at(Timestamp modified_at) {
        this.modified_at = modified_at;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }
}
