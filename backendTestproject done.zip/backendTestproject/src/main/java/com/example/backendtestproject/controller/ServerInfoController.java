package com.example.backendtestproject.controller;

import com.example.backendtestproject.model.ServerInfo;
import com.example.backendtestproject.repository.ServerInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:5173")
public class ServerInfoController {

    @Autowired
    private ServerInfoRepository serverInfoRepository;

    @PostMapping("/serverinfo")
    ServerInfo newServerInfo(@RequestBody ServerInfo newServerInfo) {
        return serverInfoRepository.save(newServerInfo);
    }

    @GetMapping("/serverinfos")
    List<ServerInfo> getAllServerInfo() {
        return serverInfoRepository.findAll();
    }






    //edit

    @PutMapping("/serverinfo/{id}")
    ServerInfo updateServerInfo(@PathVariable Integer id, @RequestBody ServerInfo updatedServerInfo) {
        return serverInfoRepository.findById(id)
                .map(serverInfo -> {
                    serverInfo.setAppInfoUid(updatedServerInfo.getAppInfoUid());
                    serverInfo.setSourceHostname(updatedServerInfo.getSourceHostname());
                    serverInfo.setSourceIpAddress(updatedServerInfo.getSourceIpAddress());
                    serverInfo.setDestinationHostName(updatedServerInfo.getDestinationHostName());
                    serverInfo.setDestinationIpAddress(updatedServerInfo.getDestinationIpAddress());
                    serverInfo.setDestinationPort(updatedServerInfo.getDestinationPort());
                    serverInfo.setIpStatus(updatedServerInfo.getIpStatus());
                    serverInfo.setCreatedAt(updatedServerInfo.getCreatedAt());
                    serverInfo.setCreatedBy(updatedServerInfo.getCreatedBy());
                    serverInfo.setModifiedAt(updatedServerInfo.getModifiedAt());
                    serverInfo.setModifiedBy(updatedServerInfo.getModifiedBy());
                    return serverInfoRepository.save(serverInfo);
                })
                .orElseThrow(() -> new IllegalArgumentException("ServerInfo with ID " + id + " not found"));
    }


    //


//delete
@DeleteMapping("/serverinfo/{id}")
void deleteServerInfo(@PathVariable Integer id) {
    serverInfoRepository.deleteById(id);
}

//




}